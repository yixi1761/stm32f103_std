#include "voltameter.h"

//int main() {
//    printf("Hello, World!\n");
//    voltameter_init();
//    while (1){
//        powerCheck();
//    }
//}
/*************************************************************************
 * 初始化电量计
 * 返回参数：	   0:异常 fd:串口句柄
 *************************************************************************/
int voltameter_init(){
    fd = uart_block_init("/dev/ttyS4", 2400, 0, 8, 1, 'E');   //初始化串口
    if(fd<0){       //串口打开失败
        fd = uart_block_init("/dev/ttyS4", 2400, 0, 8, 1, 'E');
        if(fd<0){
            printf("串口打开失败\n");
            return 0;
        }
    }
    return fd;
}

struct volt powerCheck(void){
    static uint64_t tick = 0;
    if ( (0 == get_is_timeout(&tick, 1000)) || (-2 == get_is_timeout(&tick, 1000)))   //计时未超过1s 不更新电量数据
        return voltameter;

    char cmd_data[] = {0x68,0xAA,0xAA,0xAA,0xAA,0xAA,0xAA,0x68,0x11,0x04,0x33,0x34,0x42,0x35,0xBF,0x16};
    char recv_data[40];
    char sum = 0,i;
    int status ;
    //第一次运行只发送不接收
    static char step=0;
    if(step<0){
        step++;
        return voltameter;
    }
    if (step==0){
        voltameter_init();
        uart_send(fd, cmd_data, 17);
        step++;
        return voltameter;
    }

    //返回数据长度，未接收到数据返回-1,参数错误返回-2。
    if( (status = uart_block_recv(fd, recv_data, 35, 100))< 0 ) {
        printf("!!!!!!!!!接收电量错误! %d\n",status);
        step=-5;
        uart_close(fd);
        return voltameter;
    }
    //计算校验和
    for (i=0;i<26;i++){
        sum += recv_data[i];
        printf("%x ",recv_data[i]);
    }
    printf("\n");
    //数据校验
    if((recv_data[0]==0x68)&&(recv_data[7]==0x68)&&(recv_data[8]==0x91)&&(recv_data[27]==0x16)&&(recv_data[26]==sum)) {
        //计算电压值
        float voltage_data = (
                (float) ((recv_data[15] - 0x33) >> 4) * 100 +
                (float) ((recv_data[15] - 0x33) & 0x0f) * 10 +
                (float) ((recv_data[14] - 0x33) >> 4) +
                (float) ((recv_data[14] - 0x33) & 0x0f) / 10
        );
        voltameter.voltage = voltage_data;
        printf(" 原始电压值:%.1fV\n", voltage_data);
        // 解析电流值
        float current_data = (
                (float) ((recv_data[18] - 0x33) >> 4) * 100 +
                (float) ((recv_data[18] - 0x33) & 0x0f) * 10 +
                (float) ((recv_data[17] - 0x33) >> 4) +
                (float) ((recv_data[17] - 0x33) & 0x0f) / 10 +
                (float) ((recv_data[16] - 0x33) >> 4) / 100 +
                (float) ((recv_data[16] - 0x33) & 0x0f) / 1000
        );
        voltameter.current = current_data;
        printf(" 原始电流:%.3fA\n", current_data);
        // 解析功率
        float factor_data = (
                (float) ((recv_data[21] - 0x33) >> 4) * 10 +
                (float) ((recv_data[21] - 0x33) & 0x0f) +
                (float) ((recv_data[20] - 0x33) >> 4)/10 +
                (float) ((recv_data[20] - 0x33) & 0x0f) / 100 +
                (float) ((recv_data[19] - 0x33) >> 4) / 1000 +
                (float) ((recv_data[19] - 0x33) & 0x0f) / 10000
        );
        voltameter.power_factor = factor_data;
        printf(" 原始功率:%.4f KW\n", factor_data);
        // 解析电量
        float consumption_data = (
                (float) ((recv_data[25] - 0x33) >> 4) * 100000 +
                (float) ((recv_data[25] - 0x33) & 0x0f) * 10000 +
                (float) ((recv_data[24] - 0x33) >> 4) * 1000 +
                (float) ((recv_data[24] - 0x33) & 0x0f) * 100 +
                (float) ((recv_data[23] - 0x33) >> 4) * 10 +
                (float) ((recv_data[23] - 0x33) & 0x0f) +
                (float) ((recv_data[22] - 0x33) >> 4) / 10 +
                (float) ((recv_data[22] - 0x33) & 0x0f) / 100
        );
        voltameter.power_consumption = consumption_data;
        printf(" 原始电量:%.2f KWh\n", consumption_data);
    } else{
        printf("数据校验失败!");
        for (i=0;i<28;i++){
            printf("%x ",recv_data[i]);
        }
        printf("\n");
    }

    printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~电压值:%.1f\n",voltameter.voltage);
    printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~电流值:%.3f\n",voltameter.current);
    printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~功率值:%.4f\n",voltameter.power_factor);
    printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~电量值:%.2f\n",voltameter.power_consumption);
    //记录进程运行时间
    struct timespec ts;
    clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &ts);
    printf("运行时间: %ld 分 %ld 秒\n" ,ts.tv_sec/60,ts.tv_sec%60 );

    uart_send(fd, cmd_data, 17);
    return voltameter;
}
