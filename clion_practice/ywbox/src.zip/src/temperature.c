#include "temperature.h"

//void main(){
//    printf("hello!\n");
//    float *aa;
//    while(1){
//        aa=temp_humid_get();
//        printf("aa %.1f\n",aa[1]);
//        sleep(1);
//    }
//}

float* temp_humid_get(){
    static uint64_t tick = 0;
    if ( (0 == get_is_timeout(&tick, 1000)) || (-2 == get_is_timeout(&tick, 1000)))
        return temp_humid;

    FILE* fd;
    char recv_data[5];
    if((fd=fopen("/dev/dht12","r+"))<0){  //���ļ�
        perror("open file failure!\n");
        return temp_humid;
    }
    fread(recv_data, 6, 1, fd);
    fclose(fd);
    /*����У��� OK��������,���򷵻ؾɵ�����*/
    if (recv_data[0]+recv_data[1]+recv_data[2]+recv_data[3]==recv_data[4] ){
        temp_humid[0] = recv_data[0] + (float)recv_data[1]/10;  //ʪ��
        temp_humid[1] = recv_data[2] + (float)recv_data[3]/10;  //�¶�
    } else{
        printf("У��ʧ��!\n");
//        return temp_humid;
    }
    printf("humidity   :%.1f\n", temp_humid[0]);
    printf("temperature:%.1f\n", temp_humid[1]);
    return temp_humid;
}
/*************************************************************************
BYTE ADDR R/W Desc.
0x00 R ʪ������λ
0x01 R ʪ��С��λ

0x02 R �¶�����λ
0x03 R �¶�С��λ
0x04 R У���
*************************************************************************/
