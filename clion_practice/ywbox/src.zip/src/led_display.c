#include "led_display.h"

//int main(){
//    printf("hello!\n");
//    char a[]="111111";
//    char b[]="888999";
//    while(1){
//        led_display(a); sleep(1);
//        led_display(b); sleep(1);
//    }
//}

int led_display(char *data){
    FILE *fp = NULL;
    size_t rel_size;

    if( (fp=fopen("/dev/led_display", "r+")) == NULL ){
        //无法打开设备
        printf("error!\n");
        return -1;
    }
    rel_size = fwrite(data, 1, 7, fp);

    if(rel_size != 7) {                     //写入错误
        rel_size = fwrite(data, 1, 7, fp);
        if(rel_size != 7){
            printf("写入错误! %d\n",rel_size);
            return -2;
        }
    }
    fclose(fp);
    printf("%d\n",rel_size);
    return 1;
}