//
// Created by Ansel on 2018/12/7.
//

#ifndef __VOLTAMETER_H
#define __VOLTAMETER_H

#include"util.h"

struct volt {
    //int status; //0:正常 1:无法发送命令 2:无法读取
    float current;
    float voltage;
    float power_factor;
    float power_consumption;
}voltameter;

static int fd;

/*************************************************************************
 函数名称：	powerCheck
 功能说明：	读取解析4个电量参数,保存结构体voltameter里面.
 输入参数：	无
 返回参数：	&voltameter
 *************************************************************************/
struct volt powerCheck(void);
int voltameter_init(void);
#endif  //__VOLTAMETER_H
